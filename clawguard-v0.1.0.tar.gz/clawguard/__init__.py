"""
ClawGuard - OpenClaw Security Scanner
"""

__version__ = "0.1.0"
__author__ = "Ramiche Security"
__email__ = "security@ramiche.com"